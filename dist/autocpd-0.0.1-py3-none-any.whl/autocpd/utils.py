"""
Author         : Jie Li, Department of Statistics, London School of Economics.
Date           : 2023-09-04 14:04:33
Last Revision  : 2023-09-14 10:30:47
Last Author    : Jie Li
File Path      : /AutoCPD/src/utils.py
Description    :








Copyright (c) 2023 by Jie Li, j.li196@lse.ac.uk
All Rights Reserved.
"""
def add_one(number):
    return number + 1
