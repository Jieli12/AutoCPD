"""
Author         : Jie Li, Department of Statistics, London School of Economics.
Date           : 2023-09-14 10:27:48
Last Revision  : 2023-09-14 10:27:52
Last Author    : Jie Li
File Path      : /AutoCPD/src/__init__.py
Description    :








Copyright (c) 2023 by Jie Li, j.li196@lse.ac.uk
All Rights Reserved.
"""
